package project;

import java.io.*;

import java.sql.*;

import java.sql.PreparedStatement;

import javax.servlet.ServletException;

import javax.servlet.annotation.MultipartConfig;

import javax.servlet.annotation.WebServlet;

import javax.servlet.http.*;


@WebServlet(urlPatterns = { "/additem" })
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, maxFileSize = 1024 * 1024 * 50, maxRequestSize = 1024 * 1024 * 100)
public class AddItem extends HttpServlet {

	// this if directory name where the file will be uploaded and saved

	private static final String SAVE_DIR = "jsp";

	// this is the method which is created by system it self

	protected void processRequest(HttpServletRequest request,
			HttpServletResponse response)

	throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");

		try (PrintWriter out = response.getWriter()) {

			

			try {
				String savePath = "D:\\Online Shopping Java Project\\LadyParadise" + File.separator + SAVE_DIR;
				File fileSaveDir = new File(savePath);

				if (!fileSaveDir.exists()) {

					fileSaveDir.mkdir();

				}

				 
				String code=request.getParameter("code");
				String price=request.getParameter("price");
				String category=request.getParameter("category");
				Part part = request.getPart("image");


				String fileName = extractFileName(part);

				out.println(fileName);

				part.write(savePath + File.separator + fileName);				

				Class.forName("com.mysql.jdbc.Driver");

				Connection con = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/shopping", "root", "root");			

				

				PreparedStatement pst;
				
				pst = con.prepareStatement("insert into item(code,price,category,img_URL) values(?,?,?,?)");

				//pst.setString(1, img);				

				String filePath = savePath + File.separator + fileName;		
				pst.setString(1, code);
				pst.setString(2, price);
				pst.setString(3, category);
				pst.setString(4, fileName);
				pst.executeUpdate();
				//System.out.println(img);
				System.out.println(filePath);
				
				response.sendRedirect("/LadyParadise/jsp/home.jsp");
				
			} catch (Exception ex) {
				ex.printStackTrace();

			}

		}
	

	}
	private String extractFileName(Part part) {

		String contentDisp = part.getHeader("content-disposition");

		String[] items = contentDisp.split(";");

		for (String s : items) {

			if (s.trim().startsWith("filename")) {

				return s.substring(s.indexOf("=") + 2, s.length() - 1);

			}

		}

		return "";

	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response)

	throws ServletException, IOException {

		processRequest(request, response);

	}

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response)

	throws ServletException, IOException {

		processRequest(request, response);

	}

	@Override
	public String getServletInfo() {

		return "Short description";

	}

}