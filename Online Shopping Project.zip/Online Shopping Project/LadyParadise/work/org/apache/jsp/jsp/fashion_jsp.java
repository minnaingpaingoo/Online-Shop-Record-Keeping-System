package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.sql.*;
import java.io.*;

public final class fashion_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final javax.servlet.jsp.JspFactory _jspxFactory =
          javax.servlet.jsp.JspFactory.getDefaultFactory();

  private static java.util.List<java.lang.String> _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.tomcat.InstanceManager _jsp_instancemanager;

  public java.util.List<java.lang.String> getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_instancemanager = org.apache.jasper.runtime.InstanceManagerFactory.getInstanceManager(getServletConfig());
  }

  public void _jspDestroy() {
  }

  public void _jspService(final javax.servlet.http.HttpServletRequest request, final javax.servlet.http.HttpServletResponse response)
        throws java.io.IOException, javax.servlet.ServletException {

    final javax.servlet.jsp.PageContext pageContext;
    javax.servlet.http.HttpSession session = null;
    final javax.servlet.ServletContext application;
    final javax.servlet.ServletConfig config;
    javax.servlet.jsp.JspWriter out = null;
    final java.lang.Object page = this;
    javax.servlet.jsp.JspWriter _jspx_out = null;
    javax.servlet.jsp.PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<title>Lady Paradise Fashion Page</title>\r\n");
      out.write("<style>\r\n");
      out.write("\r\n");
      out.write("body{\r\n");
      out.write("\tbackground-image: url(bg10.jpg);\r\n");
      out.write("\tmargin: 0;\r\n");
      out.write("\tbackground-size: cover;\r\n");
      out.write("\tcolor:yellow;\r\n");
      out.write("\tbackground-attachment: fixed;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("#container {\r\n");
      out.write("\tmin-width: 960px;\r\n");
      out.write("\tfont-family: Verdana, Arial, sans-serif;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("#header {\r\n");
      out.write("\tcolor: white;\r\n");
      out.write("\ttext-align: center;\r\n");
      out.write("\tfont-family: Arial;\r\n");
      out.write("\tpadding-top: 5px;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("#nav {\r\n");
      out.write("\ttext-align: center;\r\n");
      out.write("\tfont-style: bold;\r\n");
      out.write("\tpadding-top: 3px;\r\n");
      out.write("\tpadding-bottom: 3px;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("#footer {\r\n");
      out.write("\tfont-size: 0.75em;\r\n");
      out.write("\ttext-align: center;\r\n");
      out.write("\tcolor: red;\r\n");
      out.write("\tclear:both;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("#nav input{\r\n");
      out.write("\tcolor: red;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("a{\r\n");
      out.write("\ttext-decoration:none;\r\n");
      out.write("\tcolor: red;\r\n");
      out.write("}\r\n");
      out.write("\t\r\n");
      out.write("h2{\r\n");
      out.write("\tcolor: white;\r\n");
      out.write("\ttext-align: center;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("</style>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
String itemName=request.getParameter("item"); 
      out.write("\r\n");
      out.write("<div id=\"container\">\r\n");
      out.write("\t<div id=\"header\">\r\n");
      out.write("\t<marquee behavior=\"alternate\"><h1>Lady Paradise Online Shop</h1></marquee>\r\n");
      out.write("\t</div>\r\n");
      out.write("\t<div id=\"nav\">\r\n");
      out.write("\t\t<a href=\"home.jsp\"><input type=\"button\" value=\"Home\"></a>&nbsp; &nbsp; &nbsp;\r\n");
      out.write("\t\t<a href=\"fashion.jsp?item=Fashion\"><input type=\"button\" value=\"Fashion\"></a>&nbsp; &nbsp; &nbsp;\r\n");
      out.write("\t\t<a href=\"fashion.jsp?item=Beauty\"><input type=\"button\" value=\"Beauty\"></a>&nbsp; &nbsp; &nbsp;\r\n");
      out.write("\t\t<a href=\"fashion.jsp?item=Shoes\"><input type=\"button\" value=\"Shoes\"></a>&nbsp; &nbsp; &nbsp;\r\n");
      out.write("\t\t<a href=\"fashion.jsp?item=Watches\"><input type=\"button\" value=\"Watches\"></a>&nbsp; &nbsp; &nbsp;\r\n");
      out.write("\t\t<a href=\"contact.jsp\"><input type=\"button\" value=\"Contact\"></a>&nbsp; &nbsp; &nbsp;\r\n");
      out.write("\t</div>\r\n");
      out.write("\r\n");
      out.write("\t\t<h2>");
      out.print(itemName);
      out.write(" Collections</h2>\r\n");
      out.write("\t\t\t\t");

				String item=request.getParameter("item");
				try {
					Class.forName("com.mysql.jdbc.Driver");

				} catch (Exception e) {
					System.out.println("Connection Error " + e);
				}
				
				Connection con = null;
				PreparedStatement pstmt;
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping", "root", "root");
				pstmt = con.prepareStatement("select * from item where category=?");
				 pstmt.setString(1,item);
				 
				ResultSet rs = pstmt.executeQuery();
				 
      out.write("\r\n");
      out.write("\t\t\t\t\r\n");
      out.write("\t\t\t\t<table align=\"center\" bgcolor=\"black\" style=\"color:white;\">\r\n");
      out.write("\t\t\t\t ");
 
				while(rs.next()){
					int id=rs.getInt(1); 
					String code=rs.getString(2);
					int  price=rs.getInt(3);
					String category=rs.getString(4);
					String url=rs.getString(5);
					
      out.write("\r\n");
      out.write("\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td colspan=\"2\">\r\n");
      out.write("\t\t\t\t\t\t\t<img src=\"");
      out.print(url);
      out.write("\"   width=\"200\" height=\"200\">\r\n");
      out.write("\t\t\t\t\t\t</td>\r\n");
      out.write("\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td>Code:</tdd>\r\n");
      out.write("\t\t\t\t\t\t<td>  ");
      out.print(code );
      out.write("</td>\r\n");
      out.write("\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td>Price:</td>\r\n");
      out.write("\t\t\t\t\t\t<td> ");
      out.print(price );
      out.write(" MMK</td>\r\n");
      out.write("\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td colspan=\"2\">\r\n");
      out.write("\t\t\t\t\t\t\t<a href=\"showDetail.jsp?id=");
      out.print(id);
      out.write("&price=");
      out.print(price);
      out.write("&item=");
      out.print(itemName);
      out.write("\"><input type=\"button\" value=\"Order\"></a>\r\n");
      out.write("\t\t\t\t\t\t</td>\r\n");
      out.write("\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t<tr></tr><tr></tr>\r\n");
      out.write("\t\t\t\t\t");
 					 
				}
				
      out.write("\r\n");
      out.write("\t\t\t\t</table>\r\n");
      out.write("\t\t\t\t\r\n");
      out.write("\t\t\t\t\r\n");
      out.write("\t\t<div id=\"footer\">\r\n");
      out.write("\t\t\t<a href=\"mailto:ladyparadise@gmail.com\">ladyparadise@gmail.com</a>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("</div>\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (java.lang.Throwable t) {
      if (!(t instanceof javax.servlet.jsp.SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
