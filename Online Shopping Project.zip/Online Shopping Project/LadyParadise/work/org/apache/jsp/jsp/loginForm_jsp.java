package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class loginForm_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final javax.servlet.jsp.JspFactory _jspxFactory =
          javax.servlet.jsp.JspFactory.getDefaultFactory();

  private static java.util.List<java.lang.String> _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.tomcat.InstanceManager _jsp_instancemanager;

  public java.util.List<java.lang.String> getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_instancemanager = org.apache.jasper.runtime.InstanceManagerFactory.getInstanceManager(getServletConfig());
  }

  public void _jspDestroy() {
  }

  public void _jspService(final javax.servlet.http.HttpServletRequest request, final javax.servlet.http.HttpServletResponse response)
        throws java.io.IOException, javax.servlet.ServletException {

    final javax.servlet.jsp.PageContext pageContext;
    javax.servlet.http.HttpSession session = null;
    final javax.servlet.ServletContext application;
    final javax.servlet.ServletConfig config;
    javax.servlet.jsp.JspWriter out = null;
    final java.lang.Object page = this;
    javax.servlet.jsp.JspWriter _jspx_out = null;
    javax.servlet.jsp.PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<title>Customer Login Form</title>\r\n");
      out.write("<style>\r\n");
      out.write("\tbody {\r\n");
      out.write("\t\tmargin: 0;\r\n");
      out.write("\t\tpadding: 0;\r\n");
      out.write("\t\tfont-family: sans-serif;\r\n");
      out.write("\t\tbackground-image:url(bg3.jpg);\r\n");
      out.write("\t\tbackground-size:cover;\r\n");
      out.write("\t}\r\n");
      out.write("\t.box {\r\n");
      out.write("\t\tposition: absolute;\r\n");
      out.write("\t\ttop: 50%;\r\n");
      out.write("\t\tleft: 50%;\r\n");
      out.write("\t\ttransform: translate(-50%,-50%);\r\n");
      out.write("\t\twidth: 400px;\r\n");
      out.write("\t\tpadding: 40px;\r\n");
      out.write("\t\tbackground: rgba(0,0,0,.8);\r\n");
      out.write("\t\tborder-sizing: border-box;\r\n");
      out.write("\t\tbox-shadow: 0 15px 25px rgba(0,0,0,.5);\r\n");
      out.write("\t\tborder-radius: 10px;\r\n");
      out.write("\t}\r\n");
      out.write("\t.box h2 {\r\n");
      out.write("\tmargin: 0 0 30px;\r\n");
      out.write("\tpadding: 0;\r\n");
      out.write("\tcolor:#fff;\r\n");
      out.write("\ttext-align: center;\r\n");
      out.write("\t}\r\n");
      out.write("\t.box .inputBox {\r\n");
      out.write("\t\tposition: relative;\r\n");
      out.write("\t}\r\n");
      out.write("\t.box .inputBox input {\r\n");
      out.write("\t\twidth: 100%;\r\n");
      out.write("\t\tpadding: 10px 0;\r\n");
      out.write("\t\tfont-size: 16px;\r\n");
      out.write("\t\tcolor:#fff;\r\n");
      out.write("\t\tletter-spacing: 1px;\r\n");
      out.write("\t\tmargin-bottom: 30px;\r\n");
      out.write("\t\tborder: none;\r\n");
      out.write("\t\tborder: 1px solid black;\r\n");
      out.write("\t\tborder-bottom: 1px solid #fff;\r\n");
      out.write("\t\toutline: none;\r\n");
      out.write("\t\tbackground: transparent;\r\n");
      out.write("\t}\r\n");
      out.write("\t.box .inputBox label {\r\n");
      out.write("\t\tposition: absolute;\r\n");
      out.write("\t\ttop: 0;\r\n");
      out.write("\t\tleft: 0;\r\n");
      out.write("\t\tpadding: 10px 0;\r\n");
      out.write("\t\tfont-size: 16px;\r\n");
      out.write("\t\tcolor:#fff;\r\n");
      out.write("\t\tletter-spacing: 1px;\r\n");
      out.write("\t\tpointer-events: none;\r\n");
      out.write("\t\ttransition: .5s;\r\n");
      out.write("\t}\r\n");
      out.write("\t.box .inputBox input:focus ~ label,\r\n");
      out.write("\t.box .inputBox input:valid ~ label{\r\n");
      out.write("\t\ttop:-18px;\r\n");
      out.write("\t\tleft:0;\r\n");
      out.write("\t\tcolor: #03a9f4;\r\n");
      out.write("\t\tfont-size: 12px;\r\n");
      out.write("\t}\r\n");
      out.write("\t.box input[type=\"submit\"]{\r\n");
      out.write("\t\tbackground: transparent;\r\n");
      out.write("\t\tborder:none;\r\n");
      out.write("\t\toutline:none;\r\n");
      out.write("\t\tcolor:#fff;\r\n");
      out.write("\t\tbackground: #03a9f4;\r\n");
      out.write("\t\tpadding: 10px 20px;\r\n");
      out.write("\t\tcursor: pointer;\r\n");
      out.write("\t\tborder-radius: 5px; \r\n");
      out.write("\t} \r\n");
      out.write("</style>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("\t<div class=\"box\">\r\n");
      out.write("\t<h2>Login Form</h2>\r\n");
      out.write("\t\t<form action=\"login.jsp\" method=\"post\">\r\n");
      out.write("\t\t\t<div class=\"inputBox\">\r\n");
      out.write("\t\t\t\t<input type=\"email\" name=\"em\" required=\"\"/>\r\n");
      out.write("\t\t\t\t<label>Email</label>\r\n");
      out.write("\t\t\t<div/>\r\n");
      out.write("\t\t\t<div class=\"inputBox\">\r\n");
      out.write("\t\t\t\t<input type=\"password\" name=\"pass\" required=\"\"/>\r\n");
      out.write("\t\t\t\t<label>Password</label>\r\n");
      out.write("\t\t\t<div/>\r\n");
      out.write("\t\t\t<input type=\"submit\" value=\"Login\"><br> \r\n");
      out.write("\t\t\t <div style=\"color:white;\">Not Register? <a href=\"regForm.jsp\">Register</a></div>\r\n");
      out.write("\t\t</form>\r\n");
      out.write("\t</div>\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (java.lang.Throwable t) {
      if (!(t instanceof javax.servlet.jsp.SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
