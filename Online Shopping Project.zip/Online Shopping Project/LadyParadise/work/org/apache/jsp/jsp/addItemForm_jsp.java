package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class addItemForm_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final javax.servlet.jsp.JspFactory _jspxFactory =
          javax.servlet.jsp.JspFactory.getDefaultFactory();

  private static java.util.List<java.lang.String> _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.tomcat.InstanceManager _jsp_instancemanager;

  public java.util.List<java.lang.String> getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_instancemanager = org.apache.jasper.runtime.InstanceManagerFactory.getInstanceManager(getServletConfig());
  }

  public void _jspDestroy() {
  }

  public void _jspService(final javax.servlet.http.HttpServletRequest request, final javax.servlet.http.HttpServletResponse response)
        throws java.io.IOException, javax.servlet.ServletException {

    final javax.servlet.jsp.PageContext pageContext;
    javax.servlet.http.HttpSession session = null;
    final javax.servlet.ServletContext application;
    final javax.servlet.ServletConfig config;
    javax.servlet.jsp.JspWriter out = null;
    final java.lang.Object page = this;
    javax.servlet.jsp.JspWriter _jspx_out = null;
    javax.servlet.jsp.PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<title>Add Fashion Collection Page</title>\r\n");
      out.write("<style>\r\n");
      out.write("\r\n");
      out.write("body{\r\n");
      out.write("\tmargin: 0;\r\n");
      out.write("\tbackground-size: cover;\r\n");
      out.write("\tbackground-image: url(bg6.jpg);\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("#container {\r\n");
      out.write("\tcolor:#006600;\r\n");
      out.write("\tmin-width: 960px;\r\n");
      out.write("\tfont-family: Verdana, Arial, sans-serif;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("#header {\r\n");
      out.write("\tcolor: yellow;\r\n");
      out.write("\ttext-align: center;\r\n");
      out.write("\tfont-family: Arial;\r\n");
      out.write("\tpadding-top: 5px;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("#nav {\r\n");
      out.write("\ttext-align: center;\r\n");
      out.write("\tfont-style: bold;\r\n");
      out.write("\tpadding-top: 3px;\r\n");
      out.write("\tpadding-bottom: 3px;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("a{\r\n");
      out.write("\tcolor: yellow;\r\n");
      out.write("\ttext-decoration:none;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write(".box {\r\n");
      out.write("\t\tposition: absolute;\r\n");
      out.write("\t\ttop: 50%;\r\n");
      out.write("\t\tleft: 50%;\r\n");
      out.write("\t\ttransform: translate(-50%,-50%);\r\n");
      out.write("\t\twidth: 400px;\r\n");
      out.write("\t\tpadding: 40px;\r\n");
      out.write("\t\tbackground: rgba(0,0,0,.8);\r\n");
      out.write("\t\tborder-sizing: border-box;\r\n");
      out.write("\t\tbox-shadow: 0 15px 25px rgba(0,0,0,.5);\r\n");
      out.write("\t\tborder-radius: 10px;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write(".box h2 {\r\n");
      out.write("\tmargin: 0 0 30px;\r\n");
      out.write("\tpadding: 0;\r\n");
      out.write("\tcolor:#fff;\r\n");
      out.write("\ttext-align: center;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("td{\r\n");
      out.write("\tcolor:yellow;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write(".box .inputBox input {\r\n");
      out.write("\t\twidth: 100%;\r\n");
      out.write("\t\tpadding: 10px 0;\r\n");
      out.write("\t\tfont-size: 16px;\r\n");
      out.write("\t\tcolor:#fff;\r\n");
      out.write("\t\tletter-spacing: 1px;\r\n");
      out.write("\t\tmargin-bottom: 30px;\r\n");
      out.write("\t\tborder: none;\r\n");
      out.write("\t\tborder: 1px solid black;\r\n");
      out.write("\t\tborder-bottom: 1px solid #fff;\r\n");
      out.write("\t\toutline: none;\r\n");
      out.write("\t\tbackground: transparent;\r\n");
      out.write("\t}\r\n");
      out.write("\t\r\n");
      out.write("</style>\r\n");
      out.write("<script type=\"text/javascript\" src=\"EventUtil.js\"></script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("\t<div id=\"container\">\r\n");
      out.write("\t\t<div id=\"header\">\r\n");
      out.write("\t\t\t<h1>Lady Paradise Online Shop</h1>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t<div id=\"nav\">\r\n");
      out.write("\t\t<a href=\"admin.jsp\"><input type=\"button\" value=\"Home\"></a>&nbsp; &nbsp; &nbsp;\r\n");
      out.write("\t\t<a href=\"addItemForm.jsp\"><input type=\"button\" value=\"Add Item\"></a>&nbsp; &nbsp; &nbsp;\r\n");
      out.write("\t\t<a href=\"customerOrderList.jsp\"><input type=\"button\" value=\"Customer Order\"></a> &nbsp; &nbsp; &nbsp;\r\n");
      out.write("\t\t<a href=\"home.jsp\"><input type=\"button\" value=\"Logout\"></a>&nbsp; &nbsp; &nbsp;\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t<div class=\"box\">\r\n");
      out.write("\t\t<h2>Add Items</h2>\r\n");
      out.write("\t\t<form action=\"/LadyParadise/additem\" id=\"myForm\" method=\"post\" enctype=\"multipart/form-data\">\r\n");
      out.write("\t\t<table>\r\n");
      out.write("\t\t\t<tr>\r\n");
      out.write("\t\t\t\t<td>Code</td>\r\n");
      out.write("\t\t\t\t<td><input type=\"text\" name=\"code\" required></td>\r\n");
      out.write("\t\t\t</tr>\r\n");
      out.write("\t\t\t<tr>\r\n");
      out.write("\t\t\t\t<td>Price</td>\r\n");
      out.write("\t\t\t\t<td><input type=\"text\" name=\"price\" id=\"txtprice\" required></td>\r\n");
      out.write("\t\t\t</tr>\r\n");
      out.write("\t\t\t <tr>\r\n");
      out.write("\t\t\t\t<td>Category</td>\r\n");
      out.write("\t\t\t\t<td>\r\n");
      out.write("\t\t\t\t\t<select name=\"category\">\r\n");
      out.write("\t\t\t\t\t\t<option>Fashion</option>\r\n");
      out.write("\t\t\t\t\t\t<option>Beauty</option>\r\n");
      out.write("\t\t\t\t\t\t<option>Shoes</option>\r\n");
      out.write("\t\t\t\t\t\t<option>Watches</option>\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t</select>\r\n");
      out.write("\t\t\t\t</td>\r\n");
      out.write("\t\t\t  </tr>\r\n");
      out.write("\t\t\t  <tr>\r\n");
      out.write("\t\t\t\t<td>Image</td>\r\n");
      out.write("\t\t\t\t<td> <input type=\"file\" name=\"image\" required></td>\r\n");
      out.write("\t\t\t  </tr>\r\n");
      out.write("\t\t\t  <tr>\r\n");
      out.write("\t\t\t\t<td colspan=2 align=\"center\"><input type=\"submit\" value=\"Add\" ></td>\r\n");
      out.write("\t\t\t </tr>\r\n");
      out.write("\t\t</table>\r\n");
      out.write("\t\t</form>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t</div>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("(function(){\r\n");
      out.write("\t\r\n");
      out.write("var textbox=document.getElementById(\"txtprice\");\r\n");
      out.write("EventUtil.addHandler(textbox,\"keypress\",function(event){\r\n");
      out.write("\tevent=EventUtil.getEvent(event);\r\n");
      out.write("\tvar target=EventUtil.getTarget(event);\r\n");
      out.write("\tvar charCode=EventUtil.getCharCode(event);\r\n");
      out.write("\tif(!/\\d/.test(String.fromCharCode(charCode)) && charCode>9 && !event.ctrlKey){\r\n");
      out.write("\t\talert(\"*Please Enter Number.\")\r\n");
      out.write("\tEventUtil.preventDefault(event);\r\n");
      out.write("\t}\r\n");
      out.write("\t});\r\n");
      out.write("\t\r\n");
      out.write("var color=document.getElementById(\"txtcolor\");\r\n");
      out.write("EventUtil.addHandler(color,\"keypress\",function(event){\r\n");
      out.write("\tevent=EventUtil.getEvent(event);\r\n");
      out.write("\tvar target=EventUtil.getTarget(event);\r\n");
      out.write("\tvar charCode=EventUtil.getCharCode(event);\r\n");
      out.write("\tif(/\\d/.test(String.fromCharCode(charCode)) && charCode>9 && !event.ctrlKey){\r\n");
      out.write("\t\talert(\"*Please Enter Character.\")\r\n");
      out.write("\tEventUtil.preventDefault(event);\r\n");
      out.write("\t}\r\n");
      out.write("\t});\r\n");
      out.write("\t\r\n");
      out.write("})();\r\n");
      out.write("</script>\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (java.lang.Throwable t) {
      if (!(t instanceof javax.servlet.jsp.SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
